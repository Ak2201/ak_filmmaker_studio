# Obsidian Cinema Suite — Complete Design System Specification
**Product:** Filmmaker Studio (`filmmakerstudio.in`)  
**Design System ID:** `{{DATA:DESIGN_SYSTEM:DESIGN_SYSTEM_1}}`  
**Theme:** Dark Obsidian Cinema / High-Precision Film Workstation  
**Design Tokens, Primitives, UI Components & Claude Implementation Specs**

---

## 1. Design Philosophy & Foundations

The **Obsidian Cinema Suite** is crafted specifically for creative workstation software (competing in visual rigor with DaVinci Resolve, Linear, Final Draft, and Figma). It balances deep visual darkness (true cinematic immersion on OLED / reference monitors) with precise contrast, tactile micro-interactions, and auteur editorial typography.

### Core Principles
1. **True Low-Fatigue Dark Workspace:** Deep layered surfaces (`#0E0D15` base) prevent eye fatigue during 12-hour editing/writing sessions without feeling like muddy gray.
2. **Auteur Elegance Meets Industrial Tooling:** Expressive serif italics for signature titles (*Playfair Display* / *Instrument Serif*) paired with crisp Neo-Grotesque UI type (*Space Grotesk* / *Inter*) and monospaced screenplay mechanics (*JetBrains Mono* / *Courier Prime*).
3. **Intentional Chromatic Signaling:**
   - **Violet / Orchid (`#8B5CF6` / `#A855F7`):** Primary workstation action, focus states, selected projects.
   - **Cinema Amber (`#F59E0B`):** Craft knowledge, screenplay rules, production assets, warnings.
   - **Emerald / Mint (`#10B981`):** IndexedDB local sync, live gateway, clean builds.
   - **Crimson / Rose (`#EF4444`):** Failed receipts, destructive deletes, sync conflicts.

---

## 2. Design Tokens & CSS Variables

```css
:root {
  /* Surface Layers */
  --surface-canvas: #0e0d15;           /* Application base canvas */
  --surface-rail: #13121b;             /* Icon nav rail & persistent headers */
  --surface-card: #1c1b23;             /* Primary elevated containers & cards */
  --surface-elevated: #24222f;         /* Popovers, dialogs, elevated menus */
  --surface-highlight: #2e2b3d;        /* Hover fills, subtle badge backgrounds */
  --surface-active: #3a374c;           /* Selected rows, pressed controls */

  /* Borders & Dividers */
  --border-subtle: rgba(255, 255, 255, 0.07);
  --border-strong: rgba(255, 255, 255, 0.14);
  --border-focus: #8b5cf6;
  --border-amber: rgba(245, 158, 11, 0.35);

  /* Primary Brand Violet */
  --primary-50: #f5f3ff;
  --primary-100: #ede9fe;
  --primary-300: #c4b5fd;
  --primary-400: #a78bfa;
  --primary-500: #8b5cf6;             /* Core Accent */
  --primary-600: #7c3aed;
  --primary-glow: rgba(139, 92, 246, 0.25);

  /* Cinema Craft Amber */
  --amber-400: #fbbf24;
  --amber-500: #f59e0b;
  --amber-glow: rgba(245, 158, 11, 0.2);

  /* Semantic Status */
  --success: #10b981;
  --success-bg: rgba(16, 185, 129, 0.12);
  --warning: #f59e0b;
  --warning-bg: rgba(245, 158, 11, 0.12);
  --error: #ef4444;
  --error-bg: rgba(239, 68, 68, 0.12);
  --info: #38bdf8;

  /* Typography Colors */
  --text-primary: #ffffff;             /* Headings, high-emphasis values */
  --text-secondary: #9ca3af;           /* Body, table cells, secondary stats */
  --text-tertiary: #6b7280;            /* Helper labels, shortcuts, empty states */
  --text-muted: #4b5563;               /* Disabled icons, borders */

  /* Radius */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-xl: 16px;
  --radius-full: 9999px;

  /* Shadows */
  --shadow-card: 0 4px 20px -2px rgba(0, 0, 0, 0.5);
  --shadow-dialog: 0 24px 60px -12px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.1);
  --shadow-glow: 0 0 25px -4px rgba(139, 92, 246, 0.4);
}
```

---

## 3. Typography Scale & Fonts

| Role | Font Family | Tailwind Class | Usage Example |
| :--- | :--- | :--- | :--- |
| **Auteur Display Title** | `Playfair Display`, serif (*italicized*) | `font-serif italic text-4xl lg:text-5xl tracking-tight` | *"Continue where you left off."*, *"The Filmmaker's Library."* |
| **Workstation Header** | `Space Grotesk` or `Inter`, sans | `font-semibold text-2xl tracking-normal text-white` | *"Console"*, *"Your account."*, *"Members (4)"* |
| **Section Label** | `Space Grotesk`, sans | `text-xs font-mono uppercase tracking-widest text-violet-400` | `PROJECTS • ONE PER FILM`, `SECTION I: CRAFT` |
| **Body Standard** | `Inter`, sans-serif | `text-sm text-gray-300 leading-relaxed` | Descriptions, explanatory captions |
| **Telemetry & Code** | `JetBrains Mono` / `Courier Prime` | `font-mono text-xs text-gray-400` | `14.2 GB / 50 GB`, `₹1,998`, `daf2b91a-cc68...` |

---

## 4. Complete Component Library & Specifications

### 4.1 Buttons & Interactive Controls

#### Primary Violet Action (e.g. `+ New Project`, `Sync Now`)
```html
<!-- Primary Action -->
<button class="inline-flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white text-sm font-medium rounded-lg shadow-lg shadow-violet-900/30 active:scale-[0.98] transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-violet-400 focus:ring-offset-2 focus:ring-offset-[#0E0D15]">
  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
  <span>New Project</span>
</button>
```

#### Secondary Ghost Pill (e.g. `Feature`, `Short`, `Recent ▾`)
```html
<!-- Secondary Ghost Pill -->
<button class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#1C1B23] hover:bg-[#252330] text-gray-300 hover:text-white border border-white/10 rounded-lg text-xs font-medium transition-colors">
  <span>Recent</span>
  <svg class="w-3.5 h-3.5 text-gray-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></button>
```

#### Craft Shelf Action (e.g. `▶ 22 on this shelf`, `Open Active Notes`)
```html
<!-- Amber Craft Tag Action -->
<span class="inline-flex items-center gap-1.5 text-xs font-mono font-medium text-amber-400 hover:text-amber-300 cursor-pointer transition-colors">
  <span class="text-[10px]">▶</span> 22 on this shelf
</span>
```

#### Table Row Action Buttons (e.g. `Disable`, `Clear Access`, `Delete`)
```html
<!-- Table Action Buttons -->
<div class="flex items-center gap-2">
  <button class="px-2.5 py-1 text-xs font-mono uppercase tracking-wider text-gray-300 hover:text-white bg-[#252330] hover:bg-[#2E2B3D] border border-white/10 rounded transition-colors">
    Disable
  </button>
  <button class="px-2.5 py-1 text-xs font-mono uppercase tracking-wider text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded transition-colors">
    Delete Totally
  </button>
</div>
```

---

### 4.2 Dialogs & Modal Windows

```html
<!-- Modal Backdrop -->
<div class="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
  <!-- Dialog Window -->
  <div class="w-full max-w-lg bg-[#1C1B23] border border-white/10 rounded-2xl shadow-2xl p-6 relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
    <!-- Subtle Violet Glow at Top -->
    <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-violet-500 to-transparent"></div>
    
    <!-- Dialog Header -->
    <div class="flex items-start justify-between mb-4">
      <div>
        <span class="text-xs font-mono uppercase tracking-widest text-violet-400">PROJECT SETTINGS</span>
        <h3 class="text-xl font-semibold text-white mt-1">Create New Film Workspace</h3>
      </div>
      <button class="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors">
        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>
    </div>

    <!-- Dialog Body / Inputs -->
    <div class="space-y-4 py-2">
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1.5">Project Name</label>
        <input type="text" placeholder="e.g. Dragon, Leo, Vada Chennai" class="w-full px-3.5 py-2.5 bg-[#0E0D15] border border-white/10 rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500" />
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1.5">Format</label>
          <select class="w-full px-3 py-2 bg-[#0E0D15] border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-violet-500">
            <option>Feature Film</option>
            <option>Short Film</option>
            <option>Web Series</option>
          </select>
        </div>
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1.5">Regional Preset</label>
          <select class="w-full px-3 py-2 bg-[#0E0D15] border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:border-violet-500">
            <option>Tamil / Indian Standard</option>
            <option>Hollywood Standard</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Dialog Actions -->
    <div class="mt-6 flex items-center justify-end gap-3 pt-4 border-t border-white/5">
      <button class="px-4 py-2 text-xs font-medium text-gray-400 hover:text-white transition-colors">Cancel</button>
      <button class="px-5 py-2 bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-violet-900/30 transition-all">Create Film</button>
    </div>
  </div>
</div>
```

---

### 4.3 Form Inputs, Selectors & Search Bars

#### Workstation ⌘K Search Input
```html
<div class="relative w-64 md:w-80">
  <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
  </div>
  <input type="text" placeholder="Search the studio & craft shelves..." class="w-full pl-9 pr-12 py-1.5 bg-[#0E0D15]/80 hover:bg-[#0E0D15] border border-white/10 rounded-lg text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-violet-500/80 focus:ring-1 focus:ring-violet-500 transition-all" />
  <div class="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none">
    <span class="px-1.5 py-0.5 text-[10px] font-mono bg-white/5 border border-white/10 rounded text-gray-400">⌘K</span>
  </div>
</div>
```

---

### 4.4 Status Badges, Indicators & Pills

```html
<!-- Razorpay Live Status Tag -->
<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-medium bg-red-950/40 text-red-300 border border-red-500/30">
  <span class="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse"></span>
  Razorpay LIVE
</span>

<!-- Cloud / Sync Live Indicator -->
<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-medium bg-emerald-950/40 text-emerald-300 border border-emerald-500/30">
  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
  Backup: Synced
</span>

<!-- Metric Status Pill (Purchases Required) -->
<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-medium bg-amber-950/40 text-amber-300 border border-amber-500/30">
  <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
  Purchases required: ON
</span>
```

---

### 4.5 Navigation Rail & Header Specifications

#### Left Icon Rail (64px width)
- **Container:** `fixed left-0 top-0 bottom-0 w-16 bg-[#13121B] border-r border-white/10 flex flex-col justify-between items-center py-4 z-40`
- **Active State:** `bg-violet-600/20 text-violet-400 border border-violet-500/30 p-2.5 rounded-xl shadow-lg shadow-violet-950/40`
- **Inactive State:** `text-gray-400 hover:text-gray-200 hover:bg-white/5 p-2.5 rounded-xl transition-all`

#### Top Navigation Bar (56px / 14rem height)
- **Container:** `fixed top-0 left-16 right-0 h-14 bg-[#13121B]/80 backdrop-blur-md border-b border-white/10 flex items-center justify-between px-6 z-30`
- **Left:** Breadcrumbs `Studio › Library` or `Studio › Console`
- **Right:** Search `⌘K` + Feature Tag (`FEATURE Dragon ▾`) + Backup status + Dark Toggle + User Avatar `AA`

#### Bottom Persistent Telemetry Dock (32px height)
- **Container:** `fixed bottom-0 left-16 right-0 h-8 bg-[#0E0D15] border-t border-white/10 flex items-center justify-between px-4 text-[11px] font-mono text-gray-400 z-30`
- **Items:** `Filmmaker Studio v2.4 • IndexedDB Cache: Synced • Gateway: Operational • Telemetry: 14.2 GB / 50 GB`

---

### 4.6 Icon Set Map (Lucide / Material Symbols)

| Visual Item | Material Symbol / Lucide | Workstation Purpose |
| :--- | :--- | :--- |
| **Studio / Home** | `movie` / `Theaters` | Project hub, screenplay workspace |
| **Library** | `video_library` / `Library` | Curated cinema reference & 8 shelves |
| **Settings** | `settings` / `Sliders` | Account, IndexedDB, cloud sync seats |
| **Purchase** | `shopping_cart` / `CreditCard` | Lifetime licenses, tier management |
| **Console** | `terminal` / `ShieldCheck` | Admin overview, users, failed receipts |
| **Sync / Backup** | `cloud_done` / `CloudCheck` | Local IndexedDB to cloud sync |
| **Add / New** | `add` / `Plus` | Add project, grant user access |
| **External Jump** | `open_in_new` / `ExternalLink` | Open craft shelf card in view |
| **Play Indicator** | `play_arrow` / `Play` | Amber shelf count tag indicator |
| **Attention / Alert**| `error_outline` / `AlertCircle` | Failed receipt queue, unlinked sessions |
| **User Avatar** | Monogram badge | Two-letter user initials (`AA` Arun Aaron) |
