# Swiss Precision Suite — Complete Design System Specification
**Product:** Filmmaker Studio (`filmmakerstudio.in`)  
**Design System ID:** `{{DATA:DESIGN_SYSTEM:DESIGN_SYSTEM_2}}`  
**Theme:** Swiss Precision Cinema / High-Density Industrial Dark Workstation  
**Typography:** Space Grotesk (Headlines & Display), Inter (UI Controls, Body, Tables), IBM Plex Mono / JetBrains Mono (Data, Script Eighths, Timecodes, Telemetry)

---

## 1. Visual Foundation & Philosophy

The **Swiss Precision Suite** is engineered for high-density professional media workstation tools (comparable to *Linear*, *Ableton Live 12*, *Figma*, and *DaVinci Resolve Studio*). It removes decorative flourish in favor of razor-sharp geometric hierarchy, architectural hairline borders, stark monochrome surface layering, and surgical chromatic accents.

### Core Principles
1. **Zero-Fluff Architectural Geometry:** Tight, consistent corner radii (`rounded-md` / `6px` to `rounded-lg` / `8px` for containers, `rounded-full` reserved for status badges and primary action pills).
2. **Typography Hierarchy:**
   - **Display & Headings:** `Space Grotesk` (weights 500, 600, 700 with letter-spacing `-0.035em` to `-0.04em`) for modern technical authority.
   - **Workstation UI, Labels & Navigation:** `Inter` (weights 400, 500, 600) for maximum micro-legibility at 11px–13px sizes across dense data matrices.
   - **Telemetry, Script Measurements & Code:** `IBM Plex Mono` / `JetBrains Mono` with tabular numbers (`tnum`) for page fractions (`1 3/8 pp`), timecodes, DOOD codes (`SW`, `W`, `H`, `WF`), and cache telemetry.
3. **Layered Obsidian Dark Surfaces:**
   - Base Canvas: `#0D0E13` (ultra-deep matte ink ground)
   - Persistent Rails & Top Chrome: `#121318`
   - Primary Cards & Container Panels: `#1A1B21`
   - Elevated Dialogs, Drawers & Popovers: `#22232B`
   - Hover / Active Inset Fills: `#2A2B35` / `#343542`
4. **Hairline Precision Borders:** 1px borders with controlled alpha (`rgba(255, 255, 255, 0.08)` default, `rgba(255, 255, 255, 0.16)` on hover/focus).
5. **Chromatic Functionality:**
   - **Indigo / Violet Accent (`#6366F1` / `#818CF8`):** Active workstation states, locked production drafts, primary CTA buttons.
   - **Production Day Amber (`#D6A44A` / `#F59E0B`):** Exterior day scenes, logistical company move alerts, hold states.
   - **Night Blue (`#60A5FA` / `#3B82F6`):** Exterior night shooting strips, camera reel locks.
   - **Dusk Pink (`#F472B6` / `#EC4899`):** Twilight transitions and golden hour flags.
   - **Gateway Emerald (`#10B981` / `#34D399`):** Local IndexedDB sync confirmations, shot scene completions, online gateway.
   - **Destructive Crimson (`#EF4444` / `#F87171`):** Dropped scenes, deleted passes, error alerts.

---

## 2. Token Architecture (CSS Variables)

```css
:root {
  /* Surfaces */
  --surface-canvas: #0d0e13;
  --surface-rail: #121318;
  --surface-card: #1a1b21;
  --surface-elevated: #22232b;
  --surface-highlight: #2a2b35;
  --surface-active: #343542;

  /* Borders */
  --border-subtle: rgba(255, 255, 255, 0.07);
  --border-default: rgba(255, 255, 255, 0.10);
  --border-strong: rgba(255, 255, 255, 0.18);
  --border-focus: #6366f1;

  /* Chromatic Colors */
  --accent-primary: #6366f1;
  --accent-primary-hover: #4f46e5;
  --accent-glow: rgba(99, 102, 241, 0.25);

  --strip-day: #d6a44a;
  --strip-day-bg: rgba(214, 164, 74, 0.12);
  --strip-night: #60a5fa;
  --strip-night-bg: rgba(96, 165, 250, 0.12);
  --strip-dusk: #f472b6;
  --strip-dusk-bg: rgba(244, 114, 182, 0.12);
  --strip-dawn: #a78bfa;
  --strip-dawn-bg: rgba(167, 139, 250, 0.12);

  --status-success: #10b981;
  --status-warning: #f59e0b;
  --status-danger: #ef4444;

  /* Typography */
  --font-display: 'Space Grotesk', -apple-system, sans-serif;
  --font-sans: 'Inter', -apple-system, sans-serif;
  --font-mono: 'IBM Plex Mono', 'JetBrains Mono', monospace;

  /* Geometry */
  --radius-sm: 4px;
  --radius-md: 6px;
  --radius-lg: 10px;
  --radius-xl: 14px;
  --radius-pill: 9999px;
}
```

---

## 3. Component Specification & Anatomy

### 3.1 Dialogs & Modals (e.g. Confirmations, Type-to-Confirm, Project Setup)
- **Overlay Scrim:** `fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4`
- **Modal Window:** `w-full max-w-lg bg-[#22232B] border border-white/12 rounded-xl shadow-2xl overflow-hidden`
- **Header:** Mono category eyebrow (`text-xs font-mono tracking-widest text-indigo-400 uppercase`), followed by an H3 in `Space Grotesk` (`text-xl font-semibold text-white tracking-tight`). Close button `×` in top right (`w-8 h-8 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white`).
- **Body:** Body text in `Inter` (`text-sm text-gray-300 leading-relaxed`). Form inputs styled with inset `#121318` background, `border-white/10`, focus ring in `indigo-500`.
- **Typed Confirmation (e.g., `REQUIRE`, `DELETE`):** Text input with exact match verification; confirm button remains disabled with `opacity-50 cursor-not-allowed` until exact case matches.
- **Actions Bar:** `px-6 py-4 bg-[#1A1B21] border-t border-white/8 flex justify-end gap-3` with outlined `Cancel` pill button and primary action (`Lock`, `Confirm`, or danger `Delete`).

### 3.2 Iconography Standards
- **Style:** Clean 1.5px to 2px stroke weight line icons (Material Symbols Outlined / Lucide).
- **Scale:**
  - Micro / Inline: `14px × 14px` (inside buttons, badges, table actions)
  - Standard / Nav: `18px × 18px` to `20px × 20px` (top bar, rail icon tabs)
  - Prominent / Empty State: `32px × 32px` to `48px × 48px`
- **Color States:** Default `text-gray-400`, hover `text-white`, active `text-indigo-400`.

### 3.3 Buttons & Interactive Controls
- **Primary Workstation Pill:** `px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow-md shadow-indigo-950/40 transition-all flex items-center gap-2`
- **Outlined Secondary Button:** `px-3.5 py-1.5 bg-[#1A1B21] hover:bg-[#252630] border border-white/10 hover:border-white/20 text-gray-200 text-xs font-medium rounded-lg transition-colors`
- **Danger Pill:** `px-3.5 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-medium rounded-lg transition-colors`
- **Segmented Control Switcher:** Raised container `#121318` with active button `bg-[#2A2B35] text-white shadow-sm font-medium`, inactive `text-gray-400 hover:text-gray-200`.

### 3.4 Form Elements & Inputs
- **Text & Number Inputs:** Height `36px` (`h-9`), padding `px-3`, background `#121318`, border `1px solid rgba(255,255,255,0.1)`, rounded `rounded-lg`, font `Inter text-xs text-white`, placeholder `text-gray-500`, focus ring `focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500`.
- **Monospace Telemetry Inputs:** Font `IBM Plex Mono text-xs tracking-tight` for eighths and counts.
- **Select Dropdowns:** Custom chevron SVG indicator, dark popover menu with `bg-[#22232B] border-white/10`.

### 3.5 Status Badges & Chromatic Pills
- **Shoot Day (DAY):** `bg-[#D6A44A]/15 text-[#E8C384] border border-[#D6A44A]/40 text-[11px] font-mono px-2 py-0.5 rounded-full`
- **Night Scene (NIGHT):** `bg-[#60A5FA]/15 text-[#93C5FD] border border-[#60A5FA]/40 text-[11px] font-mono px-2 py-0.5 rounded-full`
- **DOOD Status (SW / W / H / WF):**
  - `SW` (Start Work): `bg-indigo-600 text-white font-mono font-bold text-xs rounded px-2 py-1`
  - `W` (Work): `bg-indigo-500/20 text-indigo-300 font-mono text-xs rounded px-2 py-1 border border-indigo-500/30`
  - `H` (Hold): `bg-amber-500/20 text-amber-300 font-mono text-xs rounded px-2 py-1 border border-amber-500/30`
  - `WF` (Work Finish): `bg-purple-600 text-white font-mono font-bold text-xs rounded px-2 py-1`
- **Gateway Sync:** `bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full px-2.5 py-0.5 text-xs font-mono flex items-center gap-1.5`

### 3.6 Workstation Data Tables & Stripboard Racks
- **Sticky Table Header:** `bg-[#121318] text-[11px] font-mono uppercase tracking-wider text-gray-400 py-2.5 px-4 border-b border-white/10`
- **Table Rows:** Hairline borders `border-b border-white/5 hover:bg-white/[0.02] transition-colors py-3 px-4 text-xs text-gray-200`
- **Stripboard Rack Item:** Card with 4px left border matching time-of-day hue, draggable grip handle `⠿`, INT/EXT badge, page count in eighths (`1 3/8 pp`), cast list chips, and day assignment selector.
