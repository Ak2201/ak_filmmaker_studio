---
name: Cinematic Precision
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393f'
  surface-container-lowest: '#0d0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#292a2f'
  surface-container-highest: '#34343a'
  on-surface: '#e3e1e9'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#e3e1e9'
  inverse-on-surface: '#2f3036'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#bdc2ff'
  on-secondary: '#131e8c'
  secondary-container: '#2f3aa3'
  on-secondary-container: '#a8afff'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#e0e0ff'
  secondary-fixed-dim: '#bdc2ff'
  on-secondary-fixed: '#000767'
  on-secondary-fixed-variant: '#2f3aa3'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#121318'
  on-background: '#e3e1e9'
  surface-variant: '#34343a'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets independent filmmakers, showrunners, screenwriters, and line producers who require an elite, high-precision environment for pre-production workflows. The aesthetic merges the disciplined functionality of professional post-production suites (DaVinci Resolve) with the fluid minimalism of modern technical productivity tools (Linear).

The emotional tone balances obsessive craft with effortless momentum. Interface layers convey a calibrated studio workspace: focused, nocturnal, and tactile. Elements leverage deep cinematic obsidian surfaces, sharp editorial rhythm, fine-line technical framing, and deliberate neon accent strikes. Visual density stays balanced between deep negative space and information-dense production artifacts (stripboards, scene breakdowns, script margins).

## Colors

- **Canvas & Surface Base:** Deep obsidian (`#090A0F`) functions as the root viewport. Mid-ground surfaces and sectional bands step up to midnight charcoal (`#0E1017`).
- **Interactive Surfaces:** Floating modules, scene stripboards, and cards utilize layered obsidian glass (`#151822`) structured with precise, low-luminance borders (`#262B3D`).
- **Primary Accentuation:** Electric Indigo (`#6366F1`) and its hover tint (`#818CF8`) designate forward progress, conversion targets, and live production states.
- **Production Badges & Metadata:** Amber Gold (`#F59E0B`) highlights production reels, scene numbers, golden-hour scheduling markers, and high-priority strip tags.
- **Typography Contrast:** Headlines command absolute white (`#FFFFFF`) to mimic projected studio light; body copy renders in calibrated slate silver (`#94A3B8`) to eliminate ocular fatigue during extended script reviews.

## Typography

The type system blends industrial film set documentation with cutting-edge software design:
- **Headings (Space Grotesk):** Provides structured geometric energy with subtle idiosyncratic cuts, echoing architectural slate typography. Tight letter-spacing maintains authority in hero titles.
- **Body & UI Narrative (Geist):** Handles interface copy, feature explanations, and script breakdown narratives with clinical clarity and low optical noise.
- **Technical Metadata (JetBrains Mono):** Dedicated to technical film metadata, timecodes, day-out-of-days (DOOD) summaries, scene scene/page count increments, and micro badges. Render uppercase where letter spacing exceeds `0.05em`.

## Layout & Spacing

A 12-column fluid grid defines layout structures up to a maximum inner container bounds of `1280px` (`80rem`). Breakpoints align at:
- **Desktop (>= 1024px):** 12 columns, `gutter: 1.5rem`, `margin: 3rem`.
- **Tablet (768px - 1023px):** 8 columns, `gutter: 1.25rem`, `margin: 2rem`.
- **Mobile (< 768px):** 4 columns, `gutter-mobile: 1rem`, `margin-mobile: 1.25rem`.

Page pacing utilizes deliberate vertical rhythm. Major content acts are partitioned with expanded top and bottom gutters (`space-xl` multiplied by 2 to 3), maintaining an uncluttered, widescreen aspect-ratio balance across every viewport tier.

## Elevation & Depth

Visual hierarchy does not rely on diffuse, muddy drop shadows. Instead, it creates depth via structured luminosity and frosted optical tiers:

- **Surface Base (Level 0):** Flat `#090A0F`, non-elevated viewport bedrock.
- **Panel Inset (Level 1):** `#0E1017` with hairline boundary `1px solid rgba(255, 255, 255, 0.04)`.
- **Raised Glass Cards (Level 2):** `#151822` backdrop with `backdrop-filter: blur(16px)` and perimeter border `1px solid #262B3D`. Elevated slightly with an ambient occlusion shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.6)`.
- **Floating Modals & Command Overlays (Level 3):** `#151822` with top-edge specular highlights (`1px solid rgba(255, 255, 255, 0.12)` transitioning to `#262B3D` on vertical sides) alongside a subtle violet ambient back-glow: `0 24px 64px -12px rgba(99, 102, 241, 0.12)`.

## Shapes

The design system maintains a refined, hardware-like discipline using `roundedness: 1` (Soft). 

- Standard interactive controls, breakdown chips, and input fields receive base `0.25rem` (4px) radii.
- Feature cards, stripboard container panels, and floating preview decks scale to `rounded-lg` (`0.5rem` / 8px).
- Structural canvas windows and lightbox wrappers cap at `rounded-xl` (`0.75rem` / 12px).
- Circular or fully rounded forms are strictly reserved for production status pips, film reel indicators, and user avatars.

## Components

### Buttons
- **Primary CTA:** Background `#6366F1`, text `#FFFFFF`, font `Geist` semi-bold. Border: none with a top specular line (`inset 0 1px 0 rgba(255,255,255,0.2)`). Hover transitions to `#818CF8` with an external glow `0 0 20px rgba(99, 102, 241, 0.35)`.
- **Secondary Action:** Glass surface `#151822`, border `1px solid #262B3D`, text `#FFFFFF`. Hover triggers border transition to `#6366F1` and background `#1D2230`.
- **Ghost/Tertiary:** No background, text `#94A3B8`. Hover states tint text to `#FFFFFF` with minimal background wash `rgba(255, 255, 255, 0.04)`.

### Chips & Film Reel Badges
- **Production Status Badges:** Rendered in `label-mono`, enclosed in `#151822`, `1px solid rgba(245, 158, 11, 0.3)`. Text color `#F59E0B`. Prefixed with a mini amber indicator dot.
- **Scene Breakdown Chips:** Dynamic color-coded ribbons (e.g., Cast, Wardrobe, Vehicles, SFX) using 15% alpha background fills against their dedicated category hues, bounded by 1px muted hairline borders.

### Cards & Stripboards
- Feature modules and mock stripboards leverage background `#151822`, perimeter border `1px solid #262B3D`, and top-edge light catchers.
- Stripboard strips adopt a stacked tabular structure with left-border visual keys (Day Exterior, Night Interior) adhering to standard industry color coding (Yellow, Blue, Green, Pink) muted to match the dark slate canvas.

### Input Fields
- Viewport: Background `#0E1017`, border `1px solid #262B3D`, text `#FFFFFF`, placeholder `#94A3B8` at 60% opacity. 
- Focus State: Border snaps to `#6366F1` with an immediate zero-blur outline ring `0 0 0 1px #6366F1`.

### Checkboxes & Sliders
- Checkboxes: 16x16px boxes, `#0E1017` background, `1px solid #262B3D`. Checked state fills `#6366F1` with an obsidian checkmark.
- Precision Scrubbers (Timelines): Thin 2px track in `#262B3D` with electric indigo scrubber head and floating timecode chip formatted in `JetBrains Mono`.