---
name: Obsidian Cinema Suite
colors:
  surface: '#13121b'
  surface-dim: '#13121b'
  surface-bright: '#3a3841'
  surface-container-lowest: '#0e0d15'
  surface-container-low: '#1c1b23'
  surface-container: '#201f27'
  surface-container-high: '#2a2932'
  surface-container-highest: '#35343d'
  on-surface: '#e5e0ed'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e5e0ed'
  inverse-on-surface: '#312f38'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#13121b'
  on-background: '#e5e0ed'
  surface-variant: '#35343d'
typography:
  headline-2xl:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  headline-2xl-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.12em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.75rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes an immersive, focused workstation crafted specifically for directors, screenwriters, cinematographers, and production teams operating in low-light editing suites. It translates the cinematic gravitas of post-production consoles into an ultra-refined, low-eye-strain digital workspace.

### Brand Personality & Tone
- **Atmospheric & Immersive:** Dark obsidian canvas that eliminates visual glare and draws focus entirely onto scriptwriting, craft notes, and production schedules.
- **Authoritative & Literary:** Evoking the prestige of classic filmmaking libraries combined with the precision of high-end grading hardware.
- **Fluid Workstation Utility:** Dense enough to handle data-heavy breakdowns, administrative rosters, and script cards, yet spacious and tactile enough to feel like an artisanal creative suite.

### Design Style: Cinematic Glassmorphic Workstation
The visual style merges deep obsidian tonal layers with subtle violet backdrops, refined glassmorphic surfaces, hairline border structures, pill-shaped control elements, and warm gold/amber accents signifying cinematic craft and active focus.

## Colors

The palette is tuned specifically for pitch-black and calibrated grading environments, relying on deep violet-black foundations rather than sterile flat grays.

### Core Swatches
- **Canvas / Root Background:** `#0e0d15` (Deep Obsidian Ink)
- **Primary Violet:** `#8b5cf6` (Electric Violet for active states, key interactive pill highlights, and header emphasis)
- **Secondary Indigo:** `#6366f1` (Deep Indigo for progressive states, selection glows, and secondary interactive borders)
- **Tertiary Craft Amber:** `#f59e0b` (Film Reel Amber for cinema library references, craft tags, warnings, and golden script highlights)
- **Accent Lilac:** `#c4b5fd` / `#a855f7` (Secondary text accents and expressive italics)

### Surface & Functional Roles
- **Surface Level 1 (Panels):** `#14121e` with `rgba(255, 255, 255, 0.05)` borders
- **Surface Level 2 (Cards / Modals):** `#1a1727` with `rgba(139, 92, 246, 0.15)` borders
- **Surface Active / Focused:** `#221e33` with `rgba(139, 92, 246, 0.5)` borders
- **Text Dominant:** `#f8fafc`
- **Text Muted / Screenplay Sluglines:** `#94a3b8`
- **Text Subtle / Metadata:** `#64748b`
- **Status Amber / Warning:** `#f59e0b`
- **Status Coral / Danger / Signout:** `#f87171`
- **Status Emerald / Live:** `#34d399`

## Typography

The typography pairs three deliberate disciplines:
1. **Editorial Headlines (`Playfair Display`):** Used for cinematic gravitas, studio titles, film names, and expressive italicized emphasis words (e.g. *where you left off*, *The Filmmaker's Library*).
2. **Interface UI (`Plus Jakarta Sans`):** Clean, geometric, and exceptionally readable at small sizes across complex studio dashboards, lists, and settings tables.
3. **Screenplay Metadata & Slate Tags (`JetBrains Mono`):** All uppercase trackers, section roman numerals, timecodes, live status labels, and console metadata use strict monospaced tracking to invoke physical script sluglines and digital slate monitors.

## Layout & Spacing

### Layout Philosophy
The workstation employs a fixed-fluid hybrid structure designed for high-resolution production displays down to on-set tablets:
- **Navigation Spine:** A persistent vertical navigation dock (64px width on desktop) anchoring key studio modules (`Home`, `Library`, `Settings`, `Console`).
- **Workspace Canvas:** A fluid modular workspace organized on a 12-column sub-grid with structural horizontal panel dividers.
- **Top Utility Rail:** A sticky glassmorphic header (56px height) containing search, active film switcher, backup status, and studio profile controls.

### Breakpoints & Adaptive Rhythm
- **Desktop (1280px+):** Full 12-column grid. Main content margins at `margin-desktop` (3rem) with 1.75rem gutters. Horizontal multi-card layouts (e.g. 4-column metric cards, dual-pane setting splits).
- **Tablet (768px - 1279px):** 8-column layout. Sidebar compresses to compact icon rail. Card matrices shift to 2-column or 3-column spans.
- **Mobile (< 768px):** 4-column layout. Persistent navigation moves to a bottom glassmorphic tab rail. Outer margin shrinks to `1rem`. Complex admin tables switch to stacked entity cards.

## Elevation & Depth

Visual hierarchy is maintained without bright background shifts by pairing deep tonal layering, frosted backdrop glassmorphism, and hairline gradient borders.

### Surface Tiers
- **Tier 0 (Bedrock):** `#0e0d15` canvas background with subtle ambient radial gradients in deep indigo (`rgba(99, 102, 241, 0.05)`).
- **Tier 1 (Panels & Shelves):** `#14121e` with 1px border `rgba(255, 255, 255, 0.06)`. Used for broad content regions, navigation sidebars, and library lists.
- **Tier 2 (Interactive Cards & Drawers):** `#191626` background, 1px border `rgba(139, 92, 246, 0.2)`. Floating elements receive an ambient violet shadow: `0 12px 32px -4px rgba(10, 8, 20, 0.8), 0 0 0 1px rgba(139, 92, 246, 0.15)`.
- **Tier 3 (Active Selection & Overlays):** `#221e33` backdrop filter `blur(16px)` with luminous violet hairline border `rgba(168, 85, 247, 0.45)` and accent glow `0 0 20px rgba(139, 92, 246, 0.25)`.

### Glassmorphism
Top navigation bars, modal dialogs, and floating status strips utilize a backdrop filter of `blur(20px)` and background of `rgba(14, 13, 21, 0.82)`, letting illuminated stage elements faintly bleed through without sacrificing legibility.

## Shapes

The interface balances sharp technical precision with ergonomic control capsules:
- **Card Containers & Modules:** 0.75rem to 1rem (`rounded-lg`) corner radii for structured, neat containment.
- **Navigation Items & Control Pills:** Full capsule geometry (`9999px` / pill-shaped) for active section highlights, mode selectors, filter chips, and primary action triggers.
- **Input Fields & Data Cells:** 0.5rem corner radius (`rounded-md`) providing structured workstation form controls.

## Components

### Buttons
- **Primary Workstation Button:** Solid vibrant violet (`#8b5cf6`) with white text, capsule radius (`rounded-full`), padding `0.625rem 1.5rem`. On hover, elevated glow `0 0 16px rgba(139, 92, 246, 0.5)` and subtle scale lift.
- **Secondary / Ghost Pill:** Semi-translucent dark slate background (`rgba(255, 255, 255, 0.05)`), border `1px solid rgba(255, 255, 255, 0.12)`, text `#f8fafc`. Hover triggers `rgba(139, 92, 246, 0.15)` background and violet border.
- **Destructive Action:** Subtle transparent pill with `#f87171` text and border; transitions to solid muted crimson on intentional hover.

### Chips & Filter Pills
- **Active Filter:** High-contrast solid white or bright violet background pill with dark inverse typography.
- **Inactive Filter:** Bordered outline capsule (`rgba(255, 255, 255, 0.1)`), monospaced or uppercase sans typography, muted gray label.
- **Status Badges:** Compact pill tags featuring a 6px status LED indicator circle:
  - *Amber (`#f59e0b`):* Pending sync, review required, craft index.
  - *Red (`#ef4444`):* Live sync, critical billing, locked master.
  - *Emerald (`#10b981`):* Active pass, synced, clean export.

### Cards & Project Containers
- **Project Slate Card:** `#161324` background with 1px border. Displays uppercase tracking headers (`FEATURE FILM · ACTIVE · PRE-PRODUCTION`), bold serif/sans title, and subtle footer telemetry (`69% · edited just now`). Active project card receives an electric violet hairline outline (`#8b5cf6`) and soft interior gradient.
- **Craft Library Shelf Card:** Rounded container with amber Roman numeral kicker (`SECTION I`), high-contrast title, concise two-line summary, and amber play-indicator count (`▶ 22 on this shelf`).
- **Empty State / New Project Card:** Dashed 1px border `rgba(139, 92, 246, 0.3)` on transparent background with a centered plus glyph and uppercase label.

### Form Inputs & Search Fields
- **Workstation Search:** Dark trough `#12101b`, capsule border `rgba(255, 255, 255, 0.1)`, leading search icon and trailing `⌘K` keyboard accelerator pill in monospace. Focus state illuminates with `#8b5cf6` border and subtle inner shadow.
- **Data Select & Inputs:** Compact field height (38px), background `#14121f`, border `rgba(255, 255, 255, 0.08)`, text `#f8fafc`.

### Tables & Data Rosters
- **Console Member Row:** Alternating subtle hover states (`rgba(139, 92, 246, 0.04)`), monospaced headers, compact action pill cluster (`DISABLE`, `CLEAR ACCESS`, `DELETE TOTALLY`) set in small uppercase monospace buttons for deliberate operator control.