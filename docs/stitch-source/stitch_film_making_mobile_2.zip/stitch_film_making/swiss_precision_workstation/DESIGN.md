---
name: Swiss Precision Workstation
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393f'
  surface-container-lowest: '#0d0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#292a2f'
  surface-container-highest: '#34343a'
  on-surface: '#e3e1e9'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#e3e1e9'
  inverse-on-surface: '#2f3036'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#f3be61'
  on-secondary: '#422c00'
  secondary-container: '#845c00'
  on-secondary-container: '#ffdba3'
  tertiary: '#a4c9ff'
  on-tertiary: '#00315d'
  tertiary-container: '#4c93e7'
  on-tertiary-container: '#002a51'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#ffdeab'
  secondary-fixed-dim: '#f3be61'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5f4100'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#a4c9ff'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#004883'
  background: '#121318'
  on-background: '#e3e1e9'
  surface-variant: '#34343a'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  display-sm:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0em
  telemetry-xs:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.5rem
  gutter-compact: 0.25rem
  margin: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style

This design system establishes a high-density, technical workstation environment engineered for cinematic production workflows, script breakdown, scheduling matrices, and offline-first telemetry. Drawing structural and behavioral cues from Ableton Live 12, DaVinci Resolve, and Linear, the aesthetic embraces an industrial Swiss ethos: meticulous visual calibration, non-decorative hairline architecture, and zero-latency clarity under demanding production room lighting conditions.

The interface serves directors, line producers, first assistant directors (1st ADs), and post supervisors. The visual tone is disciplined, authoritative, and tactically silent—operating as precision apparatus rather than expressive software. The interface disappears behind media assets, timecode blocks, and Day-out-of-Days (DOOD) grids, surfacing critical metadata through laser-sharp micro-typography and uncompromising structural alignments.

## Colors

The palette employs a deep matte obsidian scale calculated to minimize eye strain across prolonged 14-hour editorial sessions while establishing clear structural depth without heavy shadow rendering.

### Canvas & Surface Hierarchy
- **Base Canvas (`#0D0E13`)**: Root-level canvas, global backdrop, timeline tracks, and unfocused panel gutters.
- **Chrome Rails (`#121318`)**: Persistent application shell, toolbars, utility sidebars, status dock, and panel headers.
- **Card & Panel Layer (`#1A1B21`)**: Inspector modules, asset cells, time-block units, and list item containers.
- **Elevated Dialogs & Flyouts (`#22232B`)**: Modal sheets, context menus, script element pickers, and popover overlays.
- **Hairline Strokes**: Defined via `rgba(255, 255, 255, 0.08)` for interior grid divisions and `rgba(255, 255, 255, 0.16)` for active focus bounds, panel seams, and splitters.

### Functional Chromatic Signaling
Color is never decorative; it functions strictly as stateful telemetry:
- **System Indigo / Violet (`#6366F1`)**: Primary UI focus ring, selected timeline nodes, active tooling, and locked production drafts.
- **Production Amber (`#D6A44A`)**: Day scenes, daylight exterior shooting calls, active call-sheet warnings, and logistics alerts.
- **Night Blue (`#60A5FA`)**: Night scenes, interior dark setups, and scheduled blue-hour sequences.
- **Telemetry Emerald (`#10B981`)**: IndexedDB persistent offline sync confirmations, verified takes, and sound-sync locks.
- **Collision Crimson (`#EF4444`)**: Cast schedule collisions, overtime alerts, location double-bookings, and sync drops.
- **Muted Slate (`#94A3B8`)**: Secondary metrics, unfocused labels, inactive track lanes, and structural metadata.

## Typography

The typographic hierarchy separates structural headlines, dense interface controls, and precision telemetry metrics:

1. **Space Grotesk (Architectural Structural Layer)**: Applied to board names, sequence indexers, call sheet titles, and major workstation drawer headers. It enforces geometric rigor and industrial weight without consuming excessive vertical rhythm.
2. **Inter (Interface & Micro-Controls)**: Applied across input forms, parameters, node properties, and contextual menus. Tuned for micro-legibility at 11px to 13px with zero rendering fuzziness on dark surfaces.
3. **JetBrains Mono (Telemetry & Computational Metrics)**: Reserved for timecode readouts (`01:14:22:18`), script eighths breakdown (`3/8`, `7/8`), DOOD status markers (`H`, `W`, `S`, `T`), frame rates (`23.976 fps`), and local IndexedDB state hashes. Tabular lining figures are mandatory to prevent visual jitter during real-time timeline scrubber updates.

## Layout & Spacing

The layout is built on a high-density, multi-pane docking architecture that spans edge-to-edge across horizontal screens.

### Spatial Model
- **Grid Architecture**: CSS Grid pane splitters running at 1px divider allowances with zero outer gutter waste. Panel arrangements emulate non-linear video editing suites (NLEs), allowing 2-to-4 column docking configurations.
- **Rhythm Base**: A strict 4px base increment (`space-xs`: 4px, `space-sm`: 6px, `space-md`: 8px, `space-lg`: 12px, `space-xl`: 16px).
- **Toolbars & Docks**: Fixed 36px top application bars, 28px sub-header matrix rails, and 24px micro-status footers. Compact vertical dimensions maximize viewable screen real estate for breakdown strips and multi-track stripboards.

### Responsive Behaviors
- **Desktop / Ultrawide (>1440px)**: 4-pane active layout (Left Navigator, Center Matrix/Script View, Right Inspector, Bottom Scrubber/Timeline).
- **Laptop (1024px - 1439px)**: 3-pane layout; inspector drawers collapse into persistent slide-over tabs.
- **Tablet / Field Monitor (768px - 1023px)**: Single or dual pane with vertical tab toggle; toolbars lock to 44px hit-targets without increasing typography scale.

## Elevation & Depth

This system avoids soft Gaussian blur dropshadows and skeuomorphic lighting models. Spatial differentiation is achieved exclusively through tonal stratification and high-precision hairline borders:

1. **Surface Stratification**:
   - Depth Level 0 (Base Layer `#0D0E13`): Workspace canvas, timeline backdrop, dead gutters.
   - Depth Level 1 (Structural Rail `#121318`): Sidebar panels, stripboard headers, locked columns.
   - Depth Level 2 (Interactive Modules `#1A1B21`): Draggable scene strips, breakdown cards, metadata fields.
   - Depth Level 3 (Overlays & Modals `#22232B`): Flyout drawers, context menus, character DOOD selector sheets.

2. **Hairline Seams**:
   - Sub-pixel visual separation utilizes crisp 1px borders rendered in `rgba(255, 255, 255, 0.08)`.
   - Hover states elevate border brightness to `rgba(255, 255, 255, 0.16)`.
   - Active focus or active drag operations replace borders with a 1px solid Indigo outline (`#6366F1`), with no ambient glow or bloom.

3. **Floating Overlays**:
   - In instances where a modal or dropdown overlays content, elevation is reinforced with a sharp, clipped drop shadow: `0 4px 16px rgba(0, 0, 0, 0.60)`, preserving absolute dark-room screen contrast.

## Shapes

The geometry balances technical instrument angularity with minimal tactile relief:

- **Containers & Controls**: Base radius is calibrated to `6px` (`0.375rem`), transitioning to `8px` (`0.5rem`) on top-level floating modal dialogs and scene cards.
- **Interactive Micro-controls**: Inputs, nested buttons, table rows, and timeline markers use `4px` (`0.25rem`) inner corners to prevent optical distortion inside dense cells.
- **Pill Badges**: Telemetry tags, scene number chips, day/night indicators, and sync status pills utilize full border radii (`rounded-full` / `9999px`) to immediately visually differentiate state identifiers from rectangular cards and form fields.

## Components

### Buttons
- **Primary Action**: Solid Indigo (`#6366F1`) background with `#FFFFFF` text (`font-medium`, 12px Inter). Height is 28px (compact) or 32px (standard), with 6px border radius. Focus ring: 1px offset Indigo hairline.
- **Ghost / Tool Action**: Transparent background with `rgba(255, 255, 255, 0.08)` hairline border. Transitions to `#1A1B21` background and `rgba(255, 255, 255, 0.16)` border on hover.
- **Destructive Action**: `#1A1B21` surface with `#EF4444` border hairline; text rendered in Crimson `#EF4444`.

### Input Fields & Controls
- **Workstation Inputs**: Background `#121318`, border `rgba(255, 255, 255, 0.08)`, 6px radius. Height 28px. Font is Inter 12px or JetBrains Mono 12px for time/eighth values.
- **Active Focus**: Border transitions instantly to solid `#6366F1` with zero box-shadow bloom.

### Stripboard Scene Cards
- Background `#1A1B21`, structural border `1px solid rgba(255, 255, 255, 0.08)`.
- Left-hand 3px solid vertical telemetry stripe:
  - Day Exterior / Interior: Production Amber (`#D6A44A`).
  - Night Exterior / Interior: Night Blue (`#60A5FA`).
- Drag-and-drop handles render using 6-dot matrix icons in `rgba(255, 255, 255, 0.20)`.

### Badges & Status Chips
- Pill geometry (`9999px` radius) with height 18px, horizontal padding 8px.
- **Sync Badge**: Solid dark `#0F291E` base, `1px solid rgba(16, 185, 129, 0.3)` border, text in `#10B981` (JetBrains Mono 10px uppercase).
- **Conflict Pill**: Solid dark `#2D1517` base, `1px solid rgba(239, 68, 68, 0.3)` border, text in `#EF4444`.

### Checkboxes & Segmented Toggles
- **Checkboxes**: 14x14px square, 3px border radius, `#121318` base with `rgba(255, 255, 255, 0.20)` border. Checked state fills with `#6366F1` displaying a 1.5px white checkmark.
- **Segmented Track Selectors**: Enclosed `#121318` pill tray with 4px inner buttons. Active segment switches to `#1A1B21` with `rgba(255, 255, 255, 0.12)` border.

### DOOD Matrix Cells
- Monospaced grid units (24x24px) utilizing JetBrains Mono 11px bold. 
- Empty states are rendered with a single muted dot (`·`). Active cast states highlight using contextual glyphs (`W` for Work, `H` for Hold, `S` for Start, `T` for Travel) with color tokens mapped directly to schedule parameters.